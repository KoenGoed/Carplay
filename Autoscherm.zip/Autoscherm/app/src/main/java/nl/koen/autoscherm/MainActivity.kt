package nl.koen.autoscherm

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    companion object {
        const val PREFS = "autoscherm"
        private const val SPOTIFY = "com.spotify.music"
        private const val MAPS = "com.google.android.apps.maps"
    }

    private data class AppDef(val label: String, val packages: List<String>, val tileId: Int)

    private val apps = listOf(
        AppDef("Spotify", listOf(SPOTIFY), R.id.tileSpotify),
        AppDef("Maps", listOf(MAPS), R.id.tileMaps),
        AppDef("Flitsmeister", listOf("com.flitsmeister.fmnew", "nl.flitsmeister.android"), R.id.tileFlits),
        AppDef("WhatsApp", listOf("com.whatsapp", "com.whatsapp.w4b"), R.id.tileWhatsapp),
    )

    private lateinit var prefs: SharedPreferences
    private lateinit var sessionManager: MediaSessionManager
    private val handler = Handler(Looper.getMainLooper())
    private var controller: MediaController? = null
    private var listenerAdded = false

    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var trackTitle: TextView
    private lateinit var trackArtist: TextView
    private lateinit var albumArt: ImageView
    private lateinit var mediaHint: TextView
    private lateinit var btnPlay: ImageButton

    private val clockTick = object : Runnable {
        override fun run() {
            val now = Date()
            clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            date.text = SimpleDateFormat("EEEE d MMMM", Locale("nl", "NL")).format(now)
            handler.postDelayed(this, 10_000)
        }
    }

    private val sessionsChanged =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pickController(list) }

    private val mediaCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = updateMedia()
        override fun onPlaybackStateChanged(state: PlaybackState?) = updateMedia()
        override fun onSessionDestroyed() {
            controller = null
            updateMedia()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        sessionManager = getSystemService(MediaSessionManager::class.java)

        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)
        trackTitle = findViewById(R.id.trackTitle)
        trackArtist = findViewById(R.id.trackArtist)
        albumArt = findViewById(R.id.albumArt)
        mediaHint = findViewById(R.id.mediaHint)
        btnPlay = findViewById(R.id.btnPlay)

        setupTiles()
        setupDestinations()
        setupMediaButtons()
    }

    override fun onResume() {
        super.onResume()
        // Terug in het autoscherm: zwevende knop weg
        stopService(Intent(this, BubbleService::class.java))
        handler.post(clockTick)
        connectMedia()
        hideSystemBars()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(clockTick)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (listenerAdded) sessionManager.removeOnActiveSessionsChangedListener(sessionsChanged)
        controller?.unregisterCallback(mediaCallback)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN)
    }

    // ---------- App-tegels ----------

    private fun setupTiles() {
        for (app in apps) {
            val tile = findViewById<View>(app.tileId)
            tile.findViewById<TextView>(R.id.tileLabel).text = app.label
            val intent = launchIntentFor(app)
            val pkg = intent?.component?.packageName ?: intent?.`package`
            if (pkg != null) {
                try {
                    tile.findViewById<ImageView>(R.id.tileIcon)
                        .setImageDrawable(packageManager.getApplicationIcon(pkg))
                } catch (ignored: Exception) { }
            } else {
                tile.alpha = 0.45f
            }
            tile.setOnClickListener { openApp(app) }
        }
    }

    @Suppress("DEPRECATION")
    private fun launchIntentFor(app: AppDef): Intent? {
        for (p in app.packages) {
            packageManager.getLaunchIntentForPackage(p)?.let { return it }
        }
        // Valt terug op zoeken op naam, voor het geval de pakketnaam anders is
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = packageManager.queryIntentActivities(main, 0).firstOrNull {
            it.loadLabel(packageManager).toString().contains(app.label, ignoreCase = true)
        } ?: return null
        return packageManager.getLaunchIntentForPackage(match.activityInfo.packageName)
    }

    private fun openApp(app: AppDef) {
        val intent = launchIntentFor(app)
        if (intent == null) {
            Toast.makeText(this, "${app.label} is niet geïnstalleerd", Toast.LENGTH_SHORT).show()
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(app.label))))
            } catch (ignored: Exception) { }
            return
        }
        launchWithBubble(intent)
    }

    private fun launchWithBubble(intent: Intent) {
        if (!Settings.canDrawOverlays(this) && !prefs.getBoolean("askedOverlay", false)) {
            AlertDialog.Builder(this)
                .setTitle("Terugknop aanzetten?")
                .setMessage("Dan zie je in Maps, Flitsmeister en WhatsApp een rond knopje. Eén tik en je bent terug in je autoscherm.\n\nZet bij de volgende stap 'Autoscherm' aan en ga daarna terug.")
                .setPositiveButton("Aanzetten") { _, _ ->
                    prefs.edit().putBoolean("askedOverlay", true).apply()
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
                .setNegativeButton("Niet nu") { _, _ ->
                    prefs.edit().putBoolean("askedOverlay", true).apply()
                    startOther(intent)
                }
                .show()
            return
        }
        startOther(intent)
    }

    private fun startOther(intent: Intent) {
        if (Settings.canDrawOverlays(this)) {
            try {
                startForegroundService(Intent(this, BubbleService::class.java))
            } catch (ignored: Exception) { }
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(intent)
        } catch (ignored: Exception) {
            Toast.makeText(this, "Kon de app niet openen", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Vaste bestemmingen ----------

    private fun setupDestinations() {
        bindDestination(R.id.destHome, R.id.destHomeAddr, "dest_home", "Thuis")
        bindDestination(R.id.destWork, R.id.destWorkAddr, "dest_work", "School / werk")
    }

    private fun bindDestination(boxId: Int, addrId: Int, key: String, name: String) {
        val box = findViewById<View>(boxId)
        val addrView = findViewById<TextView>(addrId)
        fun refresh() {
            addrView.text = prefs.getString(key, null)?.takeIf { it.isNotBlank() } ?: "Lang indrukken om adres in te stellen"
        }
        refresh()
        box.setOnClickListener {
            val addr = prefs.getString(key, null)
            if (addr.isNullOrBlank()) editDestination(key, name) { refresh() } else navigateTo(addr)
        }
        box.setOnLongClickListener {
            editDestination(key, name) { refresh() }
            true
        }
    }

    private fun editDestination(key: String, name: String, done: () -> Unit) {
        val input = EditText(this).apply {
            setText(prefs.getString(key, ""))
            hint = "Straat en plaats"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_POSTAL_ADDRESS
        }
        AlertDialog.Builder(this)
            .setTitle("Adres voor $name")
            .setView(input)
            .setPositiveButton("Opslaan") { _, _ ->
                prefs.edit().putString(key, input.text.toString().trim()).apply()
                done()
            }
            .setNegativeButton("Annuleren", null)
            .show()
    }

    private fun navigateTo(address: String) {
        val nav = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(address))).setPackage(MAPS)
        if (nav.resolveActivity(packageManager) != null) {
            launchWithBubble(nav)
        } else {
            Toast.makeText(this, "Google Maps is niet geïnstalleerd", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Muziek (Spotify) ----------

    private fun hasNotificationAccess(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.contains(packageName)
    }

    private fun connectMedia() {
        if (!hasNotificationAccess()) {
            mediaHint.visibility = View.VISIBLE
            trackTitle.text = "Muziek"
            trackArtist.text = "Knoppen werken al, titel zie je na het aanzetten"
            return
        }
        mediaHint.visibility = View.GONE
        val component = ComponentName(this, MediaListener::class.java)
        try {
            if (!listenerAdded) {
                sessionManager.addOnActiveSessionsChangedListener(sessionsChanged, component, handler)
                listenerAdded = true
            }
            pickController(sessionManager.getActiveSessions(component))
        } catch (ignored: SecurityException) {
            mediaHint.visibility = View.VISIBLE
        }
    }

    private fun pickController(list: List<MediaController>?) {
        val chosen = list?.firstOrNull { it.packageName == SPOTIFY } ?: list?.firstOrNull()
        if (chosen?.sessionToken == controller?.sessionToken && chosen != null) {
            updateMedia()
            return
        }
        controller?.unregisterCallback(mediaCallback)
        controller = chosen
        chosen?.registerCallback(mediaCallback, handler)
        updateMedia()
    }

    private fun updateMedia() {
        val c = controller
        val meta = c?.metadata
        if (meta == null) {
            if (hasNotificationAccess()) {
                trackTitle.text = "Niets aan het spelen"
                trackArtist.text = "Druk op afspelen om Spotify te starten"
            }
            albumArt.setImageResource(R.drawable.ic_music)
            btnPlay.setImageResource(R.drawable.ic_play)
            return
        }
        trackTitle.text = meta.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Onbekend nummer"
        trackArtist.text = meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val art = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: meta.getBitmap(MediaMetadata.METADATA_KEY_ART)
        if (art != null) albumArt.setImageBitmap(art) else albumArt.setImageResource(R.drawable.ic_music)
        btnPlay.setImageResource(if (isPlaying()) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun isPlaying() = controller?.playbackState?.state == PlaybackState.STATE_PLAYING

    private fun setupMediaButtons() {
        mediaHint.setOnClickListener {
            Toast.makeText(this, "Zet 'Autoscherm' aan en ga terug", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        findViewById<ImageButton>(R.id.btnPrev).setOnClickListener {
            controller?.transportControls?.skipToPrevious() ?: sendMediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        }
        findViewById<ImageButton>(R.id.btnNext).setOnClickListener {
            controller?.transportControls?.skipToNext() ?: sendMediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
        }
        btnPlay.setOnClickListener {
            val c = controller
            when {
                c == null -> sendMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
                isPlaying() -> c.transportControls.pause()
                else -> c.transportControls.play()
            }
        }
    }

    private fun sendMediaKey(code: Int) {
        val audio = getSystemService(AudioManager::class.java)
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }
}

# Autoscherm

Eén scherm voor in de auto met Spotify-bediening, Google Maps, Flitsmeister en WhatsApp.
Muziek bedien je zonder het scherm te verlaten. Opent je een andere app, dan zweeft er een
rond knopje met een autootje. Tik erop en je bent terug.

## APK laten bouwen door GitHub (geen Android Studio nodig)

1. Maak een gratis account op github.com en klik op **New repository**. Noem hem `autoscherm`
   en zet hem op **Private**.
2. Kies **uploading an existing file** en sleep de inhoud van deze map erin (dus de mappen
   `app`, `.github` en de losse bestanden). Klik **Commit changes**.
   Let op: de map `.github` is soms verborgen. Op Windows staat hij er gewoon bij, op een Mac
   druk je in Finder op Cmd+Shift+punt om hem te zien.
3. Ga naar het tabblad **Actions**. Na ongeveer 3 minuten staat er een groen vinkje.
4. Klik op die run en download onderaan **Autoscherm-apk**. Doe dit op je telefoon, of mail
   het zip-bestand naar jezelf.
5. Pak de zip uit op je telefoon en tik op `app-debug.apk`. Sta **installeren uit onbekende
   bronnen** toe als je Samsung daarom vraagt.

## Eenmalig instellen op je Samsung

1. **Songtitels en hoesjes**: tik in de app op de oranje melding en zet *Autoscherm* aan.
   Staat de schakelaar grijs? Ga naar Instellingen → Apps → Autoscherm → ⋮ (rechtsboven) →
   **Beperkte instellingen toestaan**, en probeer het opnieuw.
   De knoppen vorige/afspelen/volgende werken ook zonder deze stap.
2. **Terugknop**: de eerste keer dat je Maps, Flitsmeister of WhatsApp opent, vraagt de app
   of de terugknop aan mag. Zet *Autoscherm* aan bij "Boven andere apps weergeven".
3. **Thuis en school/werk**: houd de knop lang ingedrukt en vul het adres in. Daarna start één
   tik de navigatie in Google Maps.
4. Tip: zet Autoscherm uit bij batterijbesparing (Instellingen → Apps → Autoscherm → Batterij →
   **Onbeperkt**), anders kan Samsung de terugknop na een tijdje wegpoetsen.
5. Tip: met **Modi en routines** kan Samsung Autoscherm vanzelf openen zodra je telefoon met
   de Bluetooth van je auto verbindt.

Stel alles in voordat je wegrijdt. Tijdens het rijden mag je je telefoon niet vasthouden.

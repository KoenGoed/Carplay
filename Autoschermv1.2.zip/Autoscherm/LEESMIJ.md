# Autoscherm

Eén scherm voor in de auto met Spotify-bediening, Google Maps, Flitsmeister en WhatsApp.
Muziek bedien je zonder het scherm te verlaten. Opent je een andere app, dan zweeft er een
rond knopje met een autootje. Tik erop en je bent terug.

## Spraakopdrachten

Tik op de oranje microfoon, of houd het zwevende autoknopje lang ingedrukt. Voorbeelden:

- "bel mama", "bel Jan"
- "open Flitsmeister", "zet WhatsApp aan", "Spotify"
- "rij naar huis", "navigeer naar school", "rij naar Albert Heijn Lelystad"
- "speel Racoon", "pauze", "volgende", "vorige", "muziek aan"

## Updates

Elke keer dat er een nieuwe `Autoscherm.zip` in de GitHub-repository Carplay komt, bouwt GitHub
een nieuwe versie. De app ziet dat vanzelf: rechtsboven verschijnt een groene Update-knop.
De repository moet daarvoor op **Public** staan.

Het bouwbestand voor GitHub staat in `ci/workflow.yml` en hoort in de repository op
`.github/workflows/build.yml`.
